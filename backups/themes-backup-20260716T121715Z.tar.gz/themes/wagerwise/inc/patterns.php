<?php
/**
 * Page-body markup for the site's composed pages (Home, Guide, News,
 * Reviews, Complaints) — defined once here and used by wp-cli/seed.php so
 * the demo pages start out already composed. Also registered as block
 * patterns so an editor can re-insert a page's default layout later.
 */

defined( 'ABSPATH' ) || exit;

function wagerwise_homepage_pattern_markup(): string {
	return <<<'HTML'
<!-- wp:wagerwise/hero-search /-->

<!-- wp:group {"className":"ww-section ww-section--tight","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section ww-section--tight">
	<!-- wp:wagerwise/category-strip {"style":"chip"} /-->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:heading {"level":2} -->
	<h2>Top Picks This Week</h2>
	<!-- /wp:heading -->
	<!-- wp:wagerwise/top-casinos {"number":3,"featuredOnly":true,"layout":"grid"} /-->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ww-section ww-section--alt","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section ww-section--alt">
	<!-- wp:heading {"level":2} -->
	<h2>Live Tournaments</h2>
	<!-- /wp:heading -->
	<!-- wp:wagerwise/tournament-grid {"number":3} /-->
</div>
<!-- /wp:group -->

<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2} -->
			<h2>Why Trust WagerWise</h2>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p>✓ Every casino is manually reviewed against our published methodology</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph -->
			<p>✓ Ratings weigh licensing, payout speed, and bonus fairness</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph -->
			<p>✓ Licences are cross-checked against MGA, UKGC, and Curaçao registries</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph -->
			<p>✓ Reviews are revisited as operators change their terms</p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2} -->
			<h2>Latest News</h2>
			<!-- /wp:heading -->
			<!-- wp:wagerwise/guide-list {"number":2} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
HTML;
}

function wagerwise_guide_page_markup(): string {
	return <<<'HTML'
<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:heading {"level":1} -->
	<h1>Player Guide</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"ww-page-subtitle"} -->
	<p class="ww-page-subtitle">Straightforward explainers, no jargon, no upsell.</p>
	<!-- /wp:paragraph -->
	<!-- wp:wagerwise/guide-featured /-->
	<!-- wp:wagerwise/guide-list {"number":8} /-->
</div>
<!-- /wp:group -->
HTML;
}

function wagerwise_news_page_markup(): string {
	return <<<'HTML'
<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:wagerwise/news-featured /-->
	<!-- wp:wagerwise/news-grid {"number":6,"skipFirst":true} /-->
</div>
<!-- /wp:group -->
HTML;
}

function wagerwise_reviews_page_markup(): string {
	return <<<'HTML'
<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:heading {"level":1} -->
	<h1>Player Reviews</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"ww-page-subtitle"} -->
	<p class="ww-page-subtitle">Real player reviews, published after moderation.</p>
	<!-- /wp:paragraph -->
	<!-- wp:wagerwise/reviews-list {"number":12} /-->
</div>
<!-- /wp:group -->
HTML;
}

function wagerwise_complaints_page_markup(): string {
	return <<<'HTML'
<!-- wp:group {"className":"ww-section","layout":{"type":"constrained"}} -->
<div class="wp-block-group ww-section">
	<!-- wp:heading {"level":1} -->
	<h1>Complaint Resolution Center</h1>
	<!-- /wp:heading -->
	<!-- wp:paragraph {"className":"ww-page-subtitle"} -->
	<p class="ww-page-subtitle">Free mediation between players and licensed casinos.</p>
	<!-- /wp:paragraph -->
	<!-- wp:wagerwise/complaints-stats /-->
	<!-- wp:columns -->
	<div class="wp-block-columns">
		<!-- wp:column {"className":"ww-complaint-form-col"} -->
		<div class="wp-block-column ww-complaint-form-col" id="complaint-form">
			<!-- wp:heading {"level":2} -->
			<h2>File a Complaint</h2>
			<!-- /wp:heading -->
			<!-- wp:wagerwise/complaint-form /-->
		</div>
		<!-- /wp:column -->
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":2} -->
			<h2>Recently Resolved</h2>
			<!-- /wp:heading -->
			<!-- wp:wagerwise/complaints-list {"number":6} /-->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
HTML;
}

add_action( 'init', 'wagerwise_register_patterns' );

function wagerwise_register_patterns(): void {
	$patterns = array(
		'homepage-sections' => array( __( 'WagerWise: Homepage Sections', 'wagerwise' ), 'wagerwise_homepage_pattern_markup' ),
		'guide-page'        => array( __( 'WagerWise: Guide Page', 'wagerwise' ), 'wagerwise_guide_page_markup' ),
		'news-page'         => array( __( 'WagerWise: News Page', 'wagerwise' ), 'wagerwise_news_page_markup' ),
		'reviews-page'      => array( __( 'WagerWise: Reviews Page', 'wagerwise' ), 'wagerwise_reviews_page_markup' ),
		'complaints-page'   => array( __( 'WagerWise: Complaints Page', 'wagerwise' ), 'wagerwise_complaints_page_markup' ),
	);
	foreach ( $patterns as $slug => [ $title, $fn ] ) {
		register_block_pattern(
			'wagerwise/' . $slug,
			array(
				'title'      => $title,
				'categories' => array( 'wagerwise' ),
				'content'    => $fn(),
			)
		);
	}
}

add_action( 'init', 'wagerwise_register_pattern_category' );

function wagerwise_register_pattern_category(): void {
	register_block_pattern_category( 'wagerwise', array( 'label' => __( 'WagerWise', 'wagerwise' ) ) );
}
