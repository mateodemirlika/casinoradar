( function () {
	'use strict';

	// 18+ age gate (only present in the DOM when enabled in WagerWise Settings).
	var gate = document.getElementById( 'ww-age-gate' );
	if ( gate ) {
		if ( ! window.localStorage.getItem( 'ww_age_verified' ) ) {
			gate.hidden = false;
			document.body.style.overflow = 'hidden';
		}
		var yesBtn = gate.querySelector( '[data-ww-age-gate="yes"]' );
		if ( yesBtn ) {
			yesBtn.addEventListener( 'click', function () {
				window.localStorage.setItem( 'ww_age_verified', '1' );
				gate.hidden = true;
				document.body.style.overflow = '';
			} );
		}
	}
} )();
